import 'package:flutter/material.dart';
import '../models/menu_item.dart';

class MenuItemWidget extends StatelessWidget {
  final MenuItem menuItem;

  MenuItemWidget({required this.menuItem});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Image.network(menuItem.imageUrl),
        title: Text(menuItem.name),
        subtitle: Text('\$${menuItem.price.toStringAsFixed(2)}'),
        trailing: IconButton(
          icon: Icon(Icons.add_shopping_cart),
          onPressed: () {
            // Handle add to cart action
          },
        ),
      ),
    );
  }
}
