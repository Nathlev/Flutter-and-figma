class MenuItem {
  final String name;
  final double price;
  final String imageUrl;

  MenuItem({required this.name, required this.price, required this.imageUrl});
}
